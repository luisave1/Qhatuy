"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface User {
  id: string
  name: string
  email: string
  isAdmin: boolean
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string) => Promise<void>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)

  // Load user from localStorage on initial render
  useEffect(() => {
    const savedUser = localStorage.getItem("user")
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser))
      } catch (error) {
        console.error("Error parsing user from localStorage:", error)
      }
    }
  }, [])

  const login = async (email: string, password: string) => {
    // In a real app, this would be an API call to authenticate the user
    // For demo purposes, we'll just simulate a successful login

    // Check if it's the admin account
    if (email === "admin@qhatuy.com" && password === "admin123") {
      const adminUser: User = {
        id: "1",
        name: "Admin User",
        email: "admin@qhatuy.com",
        isAdmin: true,
      }
      setUser(adminUser)
      localStorage.setItem("user", JSON.stringify(adminUser))
      return
    }

    // Regular user login
    const newUser: User = {
      id: "2",
      name: email.split("@")[0], // Use part of email as name
      email,
      isAdmin: false,
    }

    setUser(newUser)
    localStorage.setItem("user", JSON.stringify(newUser))
  }

  const register = async (name: string, email: string, password: string) => {
    // In a real app, this would be an API call to register the user
    // For demo purposes, we'll just simulate a successful registration

    const newUser: User = {
      id: "3",
      name,
      email,
      isAdmin: false,
    }

    setUser(newUser)
    localStorage.setItem("user", JSON.stringify(newUser))
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
  }

  return <AuthContext.Provider value={{ user, login, register, logout }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
