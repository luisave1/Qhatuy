"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import Link from "next/link"
import type { Product } from "@/types/product"

interface SearchWithSuggestionsProps {
  placeholder?: string
  className?: string
  maxSuggestions?: number
  onSearch?: (query: string) => void
  mobile?: boolean
}

export default function SearchWithSuggestions({
  placeholder = "Buscar productos...",
  className = "",
  maxSuggestions = 5,
  onSearch,
  mobile = false,
}: SearchWithSuggestionsProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [suggestions, setSuggestions] = useState<Product[]>([])
  const [recentSearches, setRecentSearches] = useState<string[]>([])
  const [popularCategories, setPopularCategories] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const router = useRouter()
  const searchRef = useRef<HTMLDivElement>(null)

  // Fetch popular categories on mount
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch("https://fakestoreapi.com/products/categories")
        if (response.ok) {
          const data = await response.json()
          setPopularCategories(data.slice(0, 4))
        }
      } catch (error) {
        console.error("Error fetching categories:", error)
      }
    }

    fetchCategories()

    // Load recent searches from localStorage
    const savedSearches = localStorage.getItem("recentSearches")
    if (savedSearches) {
      try {
        setRecentSearches(JSON.parse(savedSearches))
      } catch (e) {
        console.error("Error parsing recent searches:", e)
      }
    }
  }, [])

  // Handle click outside to close suggestions
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  // Fetch suggestions when search query changes
  useEffect(() => {
    const fetchSuggestions = async () => {
      if (searchQuery.length < 2) {
        setSuggestions([])
        return
      }

      setIsLoading(true)
      try {
        const response = await fetch("https://fakestoreapi.com/products")
        if (response.ok) {
          const data = await response.json()
          const filteredProducts = data.filter((product: Product) =>
            product.title.toLowerCase().includes(searchQuery.toLowerCase()),
          )
          setSuggestions(filteredProducts.slice(0, maxSuggestions))
        }
      } catch (error) {
        console.error("Error fetching suggestions:", error)
      } finally {
        setIsLoading(false)
      }
    }

    const debounceTimer = setTimeout(() => {
      fetchSuggestions()
    }, 300)

    return () => clearTimeout(debounceTimer)
  }, [searchQuery, maxSuggestions])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (!searchQuery.trim()) return

    // Save to recent searches
    const updatedSearches = [searchQuery, ...recentSearches.filter((search) => search !== searchQuery)].slice(0, 5)
    setRecentSearches(updatedSearches)
    localStorage.setItem("recentSearches", JSON.stringify(updatedSearches))

    // Close suggestions
    setShowSuggestions(false)

    // Navigate to search results
    if (onSearch) {
      onSearch(searchQuery)
    } else {
      router.push(`/products?search=${encodeURIComponent(searchQuery)}`)
    }
  }

  const handleSuggestionClick = (suggestion: string) => {
    setSearchQuery(suggestion)
    setShowSuggestions(false)

    // Save to recent searches
    const updatedSearches = [suggestion, ...recentSearches.filter((search) => search !== suggestion)].slice(0, 5)
    setRecentSearches(updatedSearches)
    localStorage.setItem("recentSearches", JSON.stringify(updatedSearches))

    // Navigate to search results
    router.push(`/products?search=${encodeURIComponent(suggestion)}`)
  }

  const handleCategoryClick = (category: string) => {
    setShowSuggestions(false)
    router.push(`/products?category=${encodeURIComponent(category)}`)
  }

  const handleClearRecentSearches = () => {
    setRecentSearches([])
    localStorage.removeItem("recentSearches")
  }

  return (
    <div className={`relative ${className}`} ref={searchRef}>
      <form onSubmit={handleSearch} className="relative">
        <Input
          type="search"
          placeholder={placeholder}
          className={`pl-10 ${mobile ? "w-full" : "w-64"}`}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onFocus={() => setShowSuggestions(true)}
        />
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Button type="submit" variant="ghost" size="icon" className="absolute right-0 top-0 h-full" aria-label="Buscar">
          <Search className="h-4 w-4" />
        </Button>
      </form>

      {showSuggestions && (
        <div className="absolute z-50 mt-1 w-full bg-white rounded-md shadow-lg border border-gray-200 overflow-hidden">
          {isLoading ? (
            <div className="p-4 text-center text-sm text-gray-500">Buscando...</div>
          ) : (
            <div className="max-h-[70vh] overflow-y-auto">
              {/* Product suggestions */}
              {suggestions.length > 0 && (
                <div className="p-2">
                  <h3 className="text-xs font-medium text-gray-500 px-3 py-2">Productos sugeridos</h3>
                  <ul>
                    {suggestions.map((product) => (
                      <li key={product.id}>
                        <Link href={`/products/${product.id}`}>
                          <div className="flex items-center px-3 py-2 hover:bg-gray-100 rounded-md">
                            <div className="w-10 h-10 flex-shrink-0 mr-3">
                              <img
                                src={product.image || "/placeholder.svg"}
                                alt={product.title}
                                className="w-full h-full object-contain"
                              />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900 truncate">{product.title}</p>
                              <p className="text-sm text-gray-500">${product.price.toFixed(2)}</p>
                            </div>
                          </div>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Recent searches */}
              {recentSearches.length > 0 && (
                <div className="p-2 border-t border-gray-100">
                  <div className="flex justify-between items-center px-3 py-2">
                    <h3 className="text-xs font-medium text-gray-500">Búsquedas recientes</h3>
                    <button
                      onClick={handleClearRecentSearches}
                      className="text-xs text-purple-600 hover:text-purple-800"
                    >
                      Limpiar
                    </button>
                  </div>
                  <ul>
                    {recentSearches.map((search, index) => (
                      <li key={index}>
                        <button
                          onClick={() => handleSuggestionClick(search)}
                          className="flex items-center w-full text-left px-3 py-2 hover:bg-gray-100 rounded-md"
                        >
                          <Search className="h-4 w-4 text-gray-400 mr-3" />
                          <span className="text-sm text-gray-700">{search}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Popular categories */}
              {popularCategories.length > 0 && (
                <div className="p-2 border-t border-gray-100">
                  <h3 className="text-xs font-medium text-gray-500 px-3 py-2">Categorías populares</h3>
                  <div className="flex flex-wrap gap-2 px-3 pb-2">
                    {popularCategories.map((category, index) => (
                      <button
                        key={index}
                        onClick={() => handleCategoryClick(category)}
                        className="px-3 py-1 bg-gray-100 hover:bg-gray-200 rounded-full text-sm text-gray-700 capitalize"
                      >
                        {category}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* No results */}
              {searchQuery.length >= 2 && suggestions.length === 0 && !isLoading && (
                <div className="p-4 text-center">
                  <p className="text-sm text-gray-500">No se encontraron resultados para "{searchQuery}"</p>
                </div>
              )}

              {/* Search prompt */}
              {searchQuery.length < 2 && !isLoading && suggestions.length === 0 && recentSearches.length === 0 && (
                <div className="p-4 text-center">
                  <p className="text-sm text-gray-500">Escribe al menos 2 caracteres para buscar</p>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
