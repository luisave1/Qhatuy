"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import type { Product } from "@/types/product"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Heart } from "lucide-react"
import { useCart } from "@/context/cart-context"
import { useToast } from "@/components/ui/use-toast"

interface ProductCardProps {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  const [isWishlisted, setIsWishlisted] = useState(false)
  const { addToCart } = useCart()
  const { toast } = useToast()

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    addToCart(product)
    toast({
      title: "Producto añadido",
      description: `${product.title} ha sido añadido al carrito`,
    })
  }

  const toggleWishlist = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsWishlisted(!isWishlisted)
    toast({
      title: isWishlisted ? "Producto eliminado de favoritos" : "Producto añadido a favoritos",
      description: `${product.title} ha sido ${isWishlisted ? "eliminado de" : "añadido a"} tu lista de favoritos`,
    })
  }

  return (
    <Link href={`/products/${product.id}`}>
      <div className="bg-white rounded-lg shadow-md overflow-hidden h-full flex flex-col transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
        <div className="relative pt-[100%]">
          <img
            src={product.image || "/placeholder.svg"}
            alt={product.title}
            className="absolute top-0 left-0 w-full h-full object-contain p-4"
          />
          <button onClick={toggleWishlist} className="absolute top-2 right-2 p-1.5 bg-white rounded-full shadow-sm">
            <Heart className={`h-5 w-5 ${isWishlisted ? "fill-red-500 text-red-500" : "text-gray-400"}`} />
          </button>
        </div>
        <div className="p-4 flex-grow flex flex-col">
          <div className="mb-2">
            <span className="text-xs font-medium px-2 py-1 bg-purple-100 text-purple-800 rounded-full">
              {product.category}
            </span>
          </div>
          <h3 className="font-medium text-gray-900 mb-1 line-clamp-2">{product.title}</h3>
          <p className="text-gray-500 text-sm mb-4 line-clamp-2">{product.description}</p>
          <div className="mt-auto flex items-center justify-between">
            <span className="text-lg font-bold">${product.price.toFixed(2)}</span>
            <Button size="sm" onClick={handleAddToCart}>
              <ShoppingCart className="h-4 w-4 mr-1" /> Añadir
            </Button>
          </div>
        </div>
      </div>
    </Link>
  )
}
