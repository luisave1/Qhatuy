"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { ShoppingCart, User, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/context/cart-context"
import { useAuth } from "@/context/auth-context"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import SearchWithSuggestions from "@/components/search-with-suggestions"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const pathname = usePathname()
  const { cart } = useCart()
  const { user, logout } = useAuth()

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    window.location.href = `/products?search=${searchQuery}`
  }

  // Close mobile menu when changing routes
  useEffect(() => {
    setIsMenuOpen(false)
  }, [pathname])

  return (
    <header className="fixed top-0 left-0 right-0 bg-white shadow-md z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <span className="text-2xl font-bold text-purple-700">QHATUY</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className={`hover:text-purple-700 ${pathname === "/" ? "text-purple-700 font-medium" : ""}`}>
              Inicio
            </Link>
            <Link
              href="/products"
              className={`hover:text-purple-700 ${pathname === "/products" ? "text-purple-700 font-medium" : ""}`}
            >
              Productos
            </Link>
            <Link
              href="/about"
              className={`hover:text-purple-700 ${pathname === "/about" ? "text-purple-700 font-medium" : ""}`}
            >
              Nosotros
            </Link>
            <Link
              href="/contact"
              className={`hover:text-purple-700 ${pathname === "/contact" ? "text-purple-700 font-medium" : ""}`}
            >
              Contacto
            </Link>
          </nav>

          {/* Search, Cart, and User */}
          <div className="hidden md:flex items-center space-x-4">
            <SearchWithSuggestions />

            <Link href="/cart">
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                {cart.length > 0 && (
                  <span className="absolute -top-2 -right-2 bg-purple-700 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {cart.length}
                  </span>
                )}
              </Button>
            </Link>

            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Mi cuenta</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Link href="/profile">Perfil</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/orders">Mis pedidos</Link>
                  </DropdownMenuItem>
                  {user.isAdmin && (
                    <DropdownMenuItem>
                      <Link href="/admin">Panel de administración</Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout}>Cerrar sesión</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/login">
                <Button variant="outline">Iniciar sesión</Button>
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <Link href="/cart" className="mr-4 relative">
              <ShoppingCart className="h-5 w-5" />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-purple-700 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cart.length}
                </span>
              )}
            </Link>
            <button onClick={toggleMenu} className="text-gray-600">
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg">
          <div className="container mx-auto px-4 py-3">
            <SearchWithSuggestions mobile={true} />
            <nav className="flex flex-col space-y-3">
              <Link href="/" className={`py-2 ${pathname === "/" ? "text-purple-700 font-medium" : ""}`}>
                Inicio
              </Link>
              <Link
                href="/products"
                className={`py-2 ${pathname === "/products" ? "text-purple-700 font-medium" : ""}`}
              >
                Productos
              </Link>
              <Link href="/about" className={`py-2 ${pathname === "/about" ? "text-purple-700 font-medium" : ""}`}>
                Nosotros
              </Link>
              <Link href="/contact" className={`py-2 ${pathname === "/contact" ? "text-purple-700 font-medium" : ""}`}>
                Contacto
              </Link>
              {user ? (
                <>
                  <Link href="/profile" className="py-2">
                    Mi perfil
                  </Link>
                  <Link href="/orders" className="py-2">
                    Mis pedidos
                  </Link>
                  {user.isAdmin && (
                    <Link href="/admin" className="py-2">
                      Panel de administración
                    </Link>
                  )}
                  <button onClick={logout} className="py-2 text-left text-red-600">
                    Cerrar sesión
                  </button>
                </>
              ) : (
                <Link href="/login" className="py-2">
                  <Button className="w-full">Iniciar sesión</Button>
                </Link>
              )}
            </nav>
          </div>
        </div>
      )}
    </header>
  )
}
