"use client"

import type React from "react"

import { useState, useEffect } from "react"
import type { Product } from "@/types/product"
import ProductCard from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import SearchWithSuggestions from "@/components/search-with-suggestions"

interface ProductListProps {
  searchParams: {
    category?: string
    search?: string
  }
}

export default function ProductList({ searchParams }: ProductListProps) {
  const [products, setProducts] = useState<Product[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState(searchParams.search || "")
  const [sortOption, setSortOption] = useState("default")
  const [initialLoad, setInitialLoad] = useState(true)

  useEffect(() => {
    if (initialLoad && searchParams.search) {
      setSearchQuery(searchParams.search)
      setInitialLoad(false)
    }
  }, [initialLoad, searchParams.search])

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch("https://fakestoreapi.com/products")
        if (!response.ok) {
          throw new Error("Error al cargar los productos")
        }
        const data = await response.json()
        setProducts(data)
      } catch (err) {
        setError("No se pudieron cargar los productos")
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()
  }, [])

  useEffect(() => {
    if (products.length > 0) {
      let result = [...products]

      // Apply category filter
      if (searchParams.category) {
        result = result.filter((product) => product.category.toLowerCase() === searchParams.category?.toLowerCase())
      }

      // Apply search filter
      if (searchQuery) {
        result = result.filter(
          (product) =>
            product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            product.description.toLowerCase().includes(searchQuery.toLowerCase()),
        )
      }

      // Apply sorting
      switch (sortOption) {
        case "price-low":
          result.sort((a, b) => a.price - b.price)
          break
        case "price-high":
          result.sort((a, b) => b.price - a.price)
          break
        case "name":
          result.sort((a, b) => a.title.localeCompare(b.title))
          break
        // Default is already sorted by API
      }

      setFilteredProducts(result)
    }
  }, [products, searchParams.category, searchQuery, sortOption])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // The filtering is already handled by the useEffect
  }

  if (error) {
    return <div className="text-center text-red-500">{error}</div>
  }

  if (loading) {
    return <div className="text-center">Cargando productos...</div>
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row gap-4 mb-6 items-end">
        <div className="relative flex-grow">
          <SearchWithSuggestions
            className="w-full"
            onSearch={(query) => setSearchQuery(query)}
            placeholder="Buscar en catálogo..."
          />
        </div>
        <div className="w-full sm:w-48">
          <Select value={sortOption} onValueChange={setSortOption}>
            <SelectTrigger>
              <SelectValue placeholder="Ordenar por" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="default">Destacados</SelectItem>
              <SelectItem value="price-low">Precio: Menor a Mayor</SelectItem>
              <SelectItem value="price-high">Precio: Mayor a Menor</SelectItem>
              <SelectItem value="name">Nombre</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {filteredProducts.length === 0 ? (
        <div className="text-center py-10">
          <h3 className="text-lg font-medium mb-2">No se encontraron productos</h3>
          <p className="text-gray-500 mb-4">Intenta con otros términos de búsqueda o filtros</p>
          <Button
            onClick={() => {
              setSearchQuery("")
              setSortOption("default")
            }}
          >
            Limpiar filtros
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  )
}
