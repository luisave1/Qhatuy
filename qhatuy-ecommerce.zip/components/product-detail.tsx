"use client"

import { useState, useEffect } from "react"
import type { Product } from "@/types/product"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Heart, ArrowLeft } from "lucide-react"
import { useCart } from "@/context/cart-context"
import { useToast } from "@/components/ui/use-toast"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface ProductDetailProps {
  id: string
}

export default function ProductDetail({ id }: ProductDetailProps) {
  const [product, setProduct] = useState<Product | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [quantity, setQuantity] = useState(1)
  const [isWishlisted, setIsWishlisted] = useState(false)

  const { addToCart } = useCart()
  const { toast } = useToast()

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await fetch(`https://fakestoreapi.com/products/${id}`)
        if (!response.ok) {
          throw new Error("Error al cargar el producto")
        }
        const data = await response.json()
        setProduct(data)
      } catch (err) {
        setError("No se pudo cargar el producto")
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    fetchProduct()
  }, [id])

  const handleAddToCart = () => {
    if (product) {
      for (let i = 0; i < quantity; i++) {
        addToCart(product)
      }
      toast({
        title: "Producto añadido",
        description: `${quantity} ${quantity > 1 ? "unidades" : "unidad"} de ${product.title} ${quantity > 1 ? "han sido añadidas" : "ha sido añadida"} al carrito`,
      })
    }
  }

  const toggleWishlist = () => {
    setIsWishlisted(!isWishlisted)
    if (product) {
      toast({
        title: isWishlisted ? "Producto eliminado de favoritos" : "Producto añadido a favoritos",
        description: `${product.title} ha sido ${isWishlisted ? "eliminado de" : "añadido a"} tu lista de favoritos`,
      })
    }
  }

  if (loading) {
    return <div className="text-center py-12">Cargando producto...</div>
  }

  if (error || !product) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold text-red-500 mb-4">{error || "Producto no encontrado"}</h2>
        <Link href="/products">
          <Button>
            <ArrowLeft className="mr-2 h-4 w-4" /> Volver a productos
          </Button>
        </Link>
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <Link href="/products" className="text-purple-700 hover:underline flex items-center">
          <ArrowLeft className="mr-2 h-4 w-4" /> Volver a productos
        </Link>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="relative pt-[100%]">
            <img
              src={product.image || "/placeholder.svg"}
              alt={product.title}
              className="absolute top-0 left-0 w-full h-full object-contain"
            />
          </div>
        </div>

        <div>
          <span className="inline-block px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium mb-3 capitalize">
            {product.category}
          </span>
          <h1 className="text-2xl md:text-3xl font-bold mb-2">{product.title}</h1>
          <div className="flex items-center mb-4">
            <div className="flex items-center">
              {[1, 2, 3, 4, 5].map((star) => (
                <svg
                  key={star}
                  className={`w-5 h-5 ${
                    star <= Math.round(product.rating?.rate || 0) ? "text-yellow-400" : "text-gray-300"
                  }`}
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
              <span className="ml-2 text-gray-600">
                {product.rating?.rate || 0} ({product.rating?.count || 0} reseñas)
              </span>
            </div>
          </div>

          <p className="text-3xl font-bold mb-4">${product.price.toFixed(2)}</p>

          <p className="text-gray-700 mb-6">{product.description}</p>

          <div className="flex items-center space-x-4 mb-6">
            <div className="w-24">
              <Input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(Number.parseInt(e.target.value) || 1)}
                className="text-center"
              />
            </div>
            <span className="text-gray-500">Disponible: 10 unidades</span>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <Button size="lg" className="flex-1" onClick={handleAddToCart}>
              <ShoppingCart className="mr-2 h-5 w-5" /> Añadir al carrito
            </Button>
            <Button size="lg" variant="outline" className="flex-1" onClick={toggleWishlist}>
              <Heart className={`mr-2 h-5 w-5 ${isWishlisted ? "fill-red-500 text-red-500" : ""}`} />
              {isWishlisted ? "Guardado" : "Guardar"}
            </Button>
          </div>

          <Tabs defaultValue="description">
            <TabsList className="w-full">
              <TabsTrigger value="description" className="flex-1">
                Descripción
              </TabsTrigger>
              <TabsTrigger value="details" className="flex-1">
                Detalles
              </TabsTrigger>
              <TabsTrigger value="reviews" className="flex-1">
                Reseñas
              </TabsTrigger>
            </TabsList>
            <TabsContent value="description" className="pt-4">
              <p className="text-gray-700">{product.description}</p>
            </TabsContent>
            <TabsContent value="details" className="pt-4">
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span className="font-medium">Categoría:</span>
                  <span className="capitalize">{product.category}</span>
                </li>
                <li className="flex justify-between">
                  <span className="font-medium">ID:</span>
                  <span>{product.id}</span>
                </li>
                <li className="flex justify-between">
                  <span className="font-medium">Calificación:</span>
                  <span>{product.rating?.rate || 0}/5</span>
                </li>
              </ul>
            </TabsContent>
            <TabsContent value="reviews" className="pt-4">
              <p className="text-gray-700">
                Este producto tiene {product.rating?.count || 0} reseñas con una calificación promedio de{" "}
                {product.rating?.rate || 0}/5.
              </p>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
