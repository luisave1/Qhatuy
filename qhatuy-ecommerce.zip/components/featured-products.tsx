"use client"

import { useState, useEffect } from "react"
import type { Product } from "@/types/product"
import ProductCard from "@/components/product-card"
import { Skeleton } from "@/components/ui/skeleton"

export default function FeaturedProducts() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchFeaturedProducts = async () => {
      try {
        const response = await fetch("https://fakestoreapi.com/products?limit=4")
        if (!response.ok) {
          throw new Error("Error al cargar los productos destacados")
        }
        const data = await response.json()
        setProducts(data)
      } catch (err) {
        setError("No se pudieron cargar los productos destacados")
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    fetchFeaturedProducts()
  }, [])

  if (error) {
    return <div className="text-center text-red-500">{error}</div>
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {loading
        ? Array(4)
            .fill(0)
            .map((_, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-4">
                <Skeleton className="h-48 w-full rounded-md mb-4" />
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-6 w-1/4" />
              </div>
            ))
        : products.map((product) => <ProductCard key={product.id} product={product} />)}
    </div>
  )
}
