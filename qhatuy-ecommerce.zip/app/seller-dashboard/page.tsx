"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { ShoppingBag, Users, Package, DollarSign, Store, TrendingUp, CheckCircle, Clock } from "lucide-react"

export default function SellerDashboardPage() {
  const { toast } = useToast()
  const [storeStatus, setStoreStatus] = useState("pending") // pending, approved, rejected

  return (
    <div className="container mx-auto px-4 py-8">
      {storeStatus === "pending" && (
        <Card className="mb-8 border-yellow-200 bg-yellow-50">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="bg-yellow-100 p-2 rounded-full">
              <Clock className="h-5 w-5 text-yellow-600" />
            </div>
            <div>
              <h3 className="font-medium text-yellow-800">Tu solicitud está en revisión</h3>
              <p className="text-sm text-yellow-700">
                Estamos revisando tu información. Este proceso puede tomar hasta 48 horas.
              </p>
            </div>
            <Button variant="outline" className="ml-auto" size="sm">
              Ver estado
            </Button>
          </CardContent>
        </Card>
      )}

      <h1 className="text-3xl font-bold mb-8 flex items-center">
        <Store className="mr-2 h-8 w-8" /> Panel de Vendedor
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Ventas Totales</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$0.00</div>
            <p className="text-xs text-muted-foreground">+0% desde el mes pasado</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pedidos</CardTitle>
            <ShoppingBag className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0</div>
            <p className="text-xs text-muted-foreground">+0 desde la semana pasada</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Clientes</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0</div>
            <p className="text-xs text-muted-foreground">+0 nuevos clientes</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Productos</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0</div>
            <p className="text-xs text-muted-foreground">0 productos activos</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Resumen</TabsTrigger>
          <TabsTrigger value="products">Productos</TabsTrigger>
          <TabsTrigger value="orders">Pedidos</TabsTrigger>
          <TabsTrigger value="customers">Clientes</TabsTrigger>
          <TabsTrigger value="settings">Configuración</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="col-span-1 md:col-span-2">
              <CardHeader>
                <CardTitle>Ventas Recientes</CardTitle>
                <CardDescription>No tienes ventas recientes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[200px] flex items-center justify-center border rounded-md">
                  <div className="text-center p-4">
                    <ShoppingBag className="h-10 w-10 text-gray-300 mx-auto mb-2" />
                    <h3 className="font-medium text-gray-500 mb-1">No hay ventas aún</h3>
                    <p className="text-sm text-gray-400">
                      Las ventas aparecerán aquí cuando comiences a recibir pedidos.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Próximos Pasos</CardTitle>
                <CardDescription>Completa estos pasos para comenzar a vender</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="bg-green-100 p-1 rounded-full">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium">Crear cuenta</h4>
                      <p className="text-xs text-gray-500">Completado</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-yellow-100 p-1 rounded-full">
                      <Clock className="h-4 w-4 text-yellow-600" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium">Verificación de cuenta</h4>
                      <p className="text-xs text-gray-500">En proceso</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-gray-100 p-1 rounded-full">
                      <Store className="h-4 w-4 text-gray-400" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium">Configurar tienda</h4>
                      <p className="text-xs text-gray-500">Pendiente</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-gray-100 p-1 rounded-full">
                      <Package className="h-4 w-4 text-gray-400" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium">Añadir productos</h4>
                      <p className="text-xs text-gray-500">Pendiente</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Rendimiento de la Tienda</CardTitle>
              <CardDescription>Análisis de ventas y visitas</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <div className="h-[200px] flex items-center justify-center">
                <div className="text-center">
                  <TrendingUp className="h-10 w-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-gray-500">
                    Las estadísticas aparecerán cuando comiences a recibir tráfico y ventas
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="products">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Productos</CardTitle>
                <CardDescription>Gestiona tu catálogo de productos</CardDescription>
              </div>
              <Button>Añadir Producto</Button>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Package className="h-12 w-12 text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">No hay productos</h3>
                <p className="text-gray-500 mb-4 max-w-md">
                  Aún no has añadido ningún producto a tu tienda. Comienza añadiendo tu primer producto.
                </p>
                <Button>Añadir mi primer producto</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orders">
          <Card>
            <CardHeader>
              <CardTitle>Pedidos</CardTitle>
              <CardDescription>Gestiona los pedidos de tus clientes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <ShoppingBag className="h-12 w-12 text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">No hay pedidos</h3>
                <p className="text-gray-500 mb-4 max-w-md">
                  Aún no has recibido ningún pedido. Los pedidos aparecerán aquí cuando los clientes compren tus
                  productos.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="customers">
          <Card>
            <CardHeader>
              <CardTitle>Clientes</CardTitle>
              <CardDescription>Gestiona tus clientes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Users className="h-12 w-12 text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">No hay clientes</h3>
                <p className="text-gray-500 mb-4 max-w-md">
                  Aún no tienes clientes. Los clientes aparecerán aquí cuando realicen compras en tu tienda.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de la Tienda</CardTitle>
              <CardDescription>Gestiona la configuración de tu tienda</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Información de la Tienda</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="store-name">Nombre de la tienda</Label>
                    <Input id="store-name" placeholder="Nombre de tu tienda" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="store-url">URL de la tienda</Label>
                    <div className="flex">
                      <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">
                        qhatuy.com/
                      </span>
                      <Input id="store-url" className="rounded-l-none" placeholder="mi-tienda" />
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="store-description">Descripción de la tienda</Label>
                  <Input id="store-description" placeholder="Describe brevemente tu tienda" />
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Información de Contacto</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="contact-email">Email de contacto</Label>
                    <Input id="contact-email" type="email" placeholder="contacto@tutienda.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contact-phone">Teléfono de contacto</Label>
                    <Input id="contact-phone" placeholder="+51 123 456 789" />
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <Button
                  onClick={() =>
                    toast({
                      title: "Configuración guardada",
                      description: "Los cambios han sido guardados correctamente",
                    })
                  }
                >
                  Guardar cambios
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
