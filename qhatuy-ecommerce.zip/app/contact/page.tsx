"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { Mail, Phone, MapPin, Clock, Send, Facebook, Instagram, Linkedin, Loader2 } from "lucide-react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Error",
        description: "Por favor completa todos los campos requeridos",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    // Simulate form submission
    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Mensaje enviado",
        description: "Hemos recibido tu mensaje. Te contactaremos pronto.",
      })

      // Reset form
      setFormData({
        name: "",
        email: "",
        subject: "",
        message: "",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo enviar el mensaje. Inténtalo de nuevo más tarde.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-2">Contáctanos</h1>
      <p className="text-gray-600 mb-10">Estamos aquí para ayudarte. Ponte en contacto con nosotros.</p>

      <div className="grid md:grid-cols-2 gap-12">
        {/* Contact Form */}
        <div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-6">Envíanos un mensaje</h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">
                    Nombre completo <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    placeholder="Tu nombre"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">
                    Correo electrónico <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="tu@email.com"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject">Asunto</Label>
                <Input
                  id="subject"
                  name="subject"
                  placeholder="¿Sobre qué nos quieres contactar?"
                  value={formData.subject}
                  onChange={handleChange}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">
                  Mensaje <span className="text-red-500">*</span>
                </Label>
                <Textarea
                  id="message"
                  name="message"
                  placeholder="Escribe tu mensaje aquí..."
                  rows={5}
                  value={formData.message}
                  onChange={handleChange}
                  required
                />
              </div>

              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Enviando...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" /> Enviar mensaje
                  </>
                )}
              </Button>
            </form>
          </div>
        </div>

        {/* Contact Information */}
        <div>
          <div className="bg-white p-6 rounded-lg shadow-md mb-6">
            <h2 className="text-xl font-semibold mb-6">Información de contacto</h2>

            <div className="space-y-4">
              <div className="flex items-start">
                <MapPin className="h-5 w-5 text-purple-700 mt-1 mr-3" />
                <div>
                  <h3 className="font-medium">Dirección</h3>
                  <p className="text-gray-600">
                    Av. La Marina 2000
                    <br />
                    San Miguel, Lima
                    <br />
                    Perú
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <Phone className="h-5 w-5 text-purple-700 mt-1 mr-3" />
                <div>
                  <h3 className="font-medium">Teléfono</h3>
                  <p className="text-gray-600">
                    +51 123 456 789
                    <br />
                    +51 987 654 321
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <Mail className="h-5 w-5 text-purple-700 mt-1 mr-3" />
                <div>
                  <h3 className="font-medium">Correo electrónico</h3>
                  <p className="text-gray-600">
                    info@qhatuy.com
                    <br />
                    soporte@qhatuy.com
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <Clock className="h-5 w-5 text-purple-700 mt-1 mr-3" />
                <div>
                  <h3 className="font-medium">Horario de atención</h3>
                  <p className="text-gray-600">
                    Lunes - Viernes: 9:00 AM - 6:00 PM
                    <br />
                    Sábados: 9:00 AM - 1:00 PM
                    <br />
                    Domingos: Cerrado
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Social Media */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-6">Síguenos en redes sociales</h2>

            <div className="grid grid-cols-2 gap-4">
              <a
                href="#"
                className="flex items-center p-3 rounded-lg border border-gray-200 hover:bg-purple-50 transition-colors"
              >
                <Facebook className="h-5 w-5 text-blue-600 mr-3" />
                <span>Facebook</span>
              </a>

              <a
                href="#"
                className="flex items-center p-3 rounded-lg border border-gray-200 hover:bg-purple-50 transition-colors"
              >
                <Instagram className="h-5 w-5 text-pink-600 mr-3" />
                <span>Instagram</span>
              </a>

              <a
                href="#"
                className="flex items-center p-3 rounded-lg border border-gray-200 hover:bg-purple-50 transition-colors"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 text-green-600 mr-3"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z" />
                  <path
                    d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm6.127 17.114c-.301.42-1.508 1.478-4.19 1.478-3.459 0-6.753-1.7-8.858-4.618-1.644-2.167-1.661-4.589-.488-6.236.352-.493.81-.792 1.343-.792h.11c.278 0 .552.08.786.236.411.283.707.787.841 1.447.086.36.183.948.11 1.168-.075.22-.301.418-.548.628-.248.21-.319.321-.248.539.071.218.702 1.058 1.527 1.776 1.053.929 1.91 1.233 2.205 1.353.295.12.475.013.653-.151.179-.164.764-.892.968-1.198.204-.306.408-.254.687-.153.279.1 1.707.826 2.006.976.299.15.498.225.573.35.075.125.075.72-.126 1.397z"
                    fillRule="evenodd"
                    clipRule="evenodd"
                  />
                </svg>
                <span>WhatsApp</span>
              </a>

              <a
                href="#"
                className="flex items-center p-3 rounded-lg border border-gray-200 hover:bg-purple-50 transition-colors"
              >
                <Linkedin className="h-5 w-5 text-blue-700 mr-3" />
                <span>LinkedIn</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Map */}
      <div className="mt-12">
        <h2 className="text-xl font-semibold mb-6">Nuestra ubicación</h2>
        <div className="bg-gray-200 rounded-lg overflow-hidden h-[400px] flex items-center justify-center">
          <div className="text-center">
            <MapPin className="h-12 w-12 text-purple-700 mx-auto mb-4" />
            <p className="text-gray-600">
              Mapa de ubicación de QHATUY
              <br />
              Av. La Marina 2000, San Miguel, Lima, Perú
            </p>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="mt-12">
        <h2 className="text-xl font-semibold mb-6">Preguntas frecuentes</h2>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="font-medium text-lg mb-2">¿Cuál es el tiempo de entrega?</h3>
            <p className="text-gray-600">
              Nuestro tiempo de entrega estándar es de 3 a 5 días hábiles, dependiendo de tu ubicación. Para zonas más
              alejadas, puede tomar hasta 7 días hábiles.
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="font-medium text-lg mb-2">¿Cómo puedo rastrear mi pedido?</h3>
            <p className="text-gray-600">
              Una vez que tu pedido sea enviado, recibirás un correo electrónico con un número de seguimiento que podrás
              utilizar en nuestra sección "Mis Pedidos".
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="font-medium text-lg mb-2">¿Cuál es la política de devoluciones?</h3>
            <p className="text-gray-600">
              Aceptamos devoluciones dentro de los 14 días posteriores a la recepción del producto, siempre y cuando el
              artículo esté en su estado original.
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="font-medium text-lg mb-2">¿Ofrecen envío internacional?</h3>
            <p className="text-gray-600">
              Actualmente solo realizamos envíos dentro de Perú. Estamos trabajando para expandir nuestros servicios a
              otros países de Latinoamérica próximamente.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
