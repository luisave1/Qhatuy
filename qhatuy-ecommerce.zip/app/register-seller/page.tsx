"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { Loader2, Upload, CheckCircle } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function RegisterSellerPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [registrationComplete, setRegistrationComplete] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  // Personal Information
  const [personalInfo, setPersonalInfo] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  })

  // Business Information
  const [businessInfo, setBusinessInfo] = useState({
    businessName: "",
    businessType: "",
    ruc: "",
    description: "",
    address: "",
    city: "",
    region: "",
    postalCode: "",
    website: "",
    foundedYear: new Date().getFullYear().toString(),
  })

  // Product Information
  const [productInfo, setProductInfo] = useState({
    categories: [] as string[],
    averageProducts: "",
    shippingOptions: [] as string[],
    hasPhysicalStore: false,
  })

  // Documents
  const [documents, setDocuments] = useState({
    identityDocument: null,
    businessRegistration: null,
    taxDeclaration: null,
    acceptTerms: false,
    acceptPrivacyPolicy: false,
  })

  const handlePersonalInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setPersonalInfo((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleBusinessInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setBusinessInfo((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setBusinessInfo((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleCategoryToggle = (category: string) => {
    setProductInfo((prev) => {
      const categories = prev.categories.includes(category)
        ? prev.categories.filter((c) => c !== category)
        : [...prev.categories, category]
      return { ...prev, categories }
    })
  }

  const handleShippingToggle = (option: string) => {
    setProductInfo((prev) => {
      const shippingOptions = prev.shippingOptions.includes(option)
        ? prev.shippingOptions.filter((o) => o !== option)
        : [...prev.shippingOptions, option]
      return { ...prev, shippingOptions }
    })
  }

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setDocuments((prev) => ({
      ...prev,
      [name]: checked,
    }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, documentType: string) => {
    if (e.target.files && e.target.files[0]) {
      setDocuments((prev) => ({
        ...prev,
        [documentType]: e.target.files ? e.target.files[0] : null,
      }))
    }
  }

  const validatePersonalInfo = () => {
    if (!personalInfo.firstName || !personalInfo.lastName || !personalInfo.email || !personalInfo.phone) {
      toast({
        title: "Campos incompletos",
        description: "Por favor completa todos los campos obligatorios",
        variant: "destructive",
      })
      return false
    }

    if (!personalInfo.password || personalInfo.password.length < 8) {
      toast({
        title: "Contraseña inválida",
        description: "La contraseña debe tener al menos 8 caracteres",
        variant: "destructive",
      })
      return false
    }

    if (personalInfo.password !== personalInfo.confirmPassword) {
      toast({
        title: "Las contraseñas no coinciden",
        description: "Por favor verifica que las contraseñas sean iguales",
        variant: "destructive",
      })
      return false
    }

    return true
  }

  const validateBusinessInfo = () => {
    if (
      !businessInfo.businessName ||
      !businessInfo.businessType ||
      !businessInfo.ruc ||
      !businessInfo.description ||
      !businessInfo.address ||
      !businessInfo.city ||
      !businessInfo.region
    ) {
      toast({
        title: "Campos incompletos",
        description: "Por favor completa todos los campos obligatorios",
        variant: "destructive",
      })
      return false
    }

    // Validate RUC (Peruvian business ID) - should be 11 digits
    if (!/^\d{11}$/.test(businessInfo.ruc)) {
      toast({
        title: "RUC inválido",
        description: "El RUC debe contener 11 dígitos",
        variant: "destructive",
      })
      return false
    }

    return true
  }

  const validateProductInfo = () => {
    if (productInfo.categories.length === 0 || !productInfo.averageProducts) {
      toast({
        title: "Campos incompletos",
        description: "Por favor selecciona al menos una categoría y el número aproximado de productos",
        variant: "destructive",
      })
      return false
    }

    return true
  }

  const validateDocuments = () => {
    if (!documents.acceptTerms || !documents.acceptPrivacyPolicy) {
      toast({
        title: "Aceptación requerida",
        description: "Debes aceptar los términos y condiciones y la política de privacidad para continuar",
        variant: "destructive",
      })
      return false
    }

    return true
  }

  const handleNextStep = () => {
    if (currentStep === 1 && !validatePersonalInfo()) return
    if (currentStep === 2 && !validateBusinessInfo()) return
    if (currentStep === 3 && !validateProductInfo()) return

    setCurrentStep((prev) => prev + 1)
    window.scrollTo(0, 0)
  }

  const handlePreviousStep = () => {
    setCurrentStep((prev) => prev - 1)
    window.scrollTo(0, 0)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateDocuments()) return

    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Success
      setRegistrationComplete(true)
      window.scrollTo(0, 0)

      toast({
        title: "Registro exitoso",
        description: "Tu solicitud ha sido enviada y está siendo revisada",
      })
    } catch (error) {
      toast({
        title: "Error en el registro",
        description: "Ha ocurrido un error al procesar tu solicitud. Por favor intenta nuevamente.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const goToDashboard = () => {
    router.push("/seller-dashboard")
  }

  if (registrationComplete) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <Card className="border-green-200 shadow-lg">
          <CardHeader className="text-center bg-green-50 border-b border-green-100">
            <div className="mx-auto mb-4 bg-green-100 w-16 h-16 rounded-full flex items-center justify-center">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl text-green-800">¡Registro Completado!</CardTitle>
            <CardDescription className="text-green-700">
              Tu solicitud para convertirte en vendedor ha sido recibida
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-4 text-center">
              <p className="text-gray-700">
                Gracias por registrarte como vendedor en QHATUY. Hemos recibido tu solicitud y nuestro equipo la
                revisará en las próximas 24-48 horas.
              </p>
              <p className="text-gray-700">
                Te enviaremos un correo electrónico a <span className="font-medium">{personalInfo.email}</span> con los
                siguientes pasos una vez que tu cuenta haya sido aprobada.
              </p>

              <div className="bg-blue-50 p-4 rounded-lg mt-6">
                <h3 className="font-medium text-blue-800 mb-2">¿Qué sigue?</h3>
                <ul className="text-left text-blue-700 space-y-2">
                  <li className="flex items-start">
                    <span className="mr-2">1.</span>
                    <span>Revisaremos tu solicitud y verificaremos la información proporcionada.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">2.</span>
                    <span>Recibirás un correo electrónico de confirmación cuando tu cuenta sea aprobada.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">3.</span>
                    <span>
                      Podrás acceder a tu panel de vendedor y comenzar a configurar tu tienda y subir productos.
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col space-y-3">
            <Button className="w-full" onClick={goToDashboard}>
              Ir al Panel de Vendedor
            </Button>
            <Link href="/" className="w-full">
              <Button variant="outline" className="w-full">
                Volver al Inicio
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Regístrate como Vendedor</h1>
          <p className="text-gray-600">Únete a QHATUY y lleva tu negocio al siguiente nivel</p>
        </div>

        <div className="mb-8">
          <div className="flex justify-between items-center">
            {[1, 2, 3, 4].map((step) => (
              <div
                key={step}
                className={`flex flex-col items-center ${
                  step < currentStep ? "text-green-600" : step === currentStep ? "text-purple-700" : "text-gray-400"
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${
                    step < currentStep
                      ? "bg-green-100 border-2 border-green-600"
                      : step === currentStep
                        ? "bg-purple-100 border-2 border-purple-700"
                        : "bg-gray-100 border-2 border-gray-300"
                  }`}
                >
                  {step < currentStep ? (
                    <CheckCircle className="h-5 w-5" />
                  ) : (
                    <span className="font-medium">{step}</span>
                  )}
                </div>
                <span
                  className={`text-sm hidden sm:block ${
                    step < currentStep
                      ? "text-green-600 font-medium"
                      : step === currentStep
                        ? "text-purple-700 font-medium"
                        : "text-gray-400"
                  }`}
                >
                  {step === 1
                    ? "Información Personal"
                    : step === 2
                      ? "Datos del Negocio"
                      : step === 3
                        ? "Productos"
                        : "Documentos"}
                </span>
              </div>
            ))}
          </div>
          <div className="relative mt-2">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gray-200 rounded-full"></div>
            <div
              className="absolute top-0 left-0 h-1 bg-purple-700 rounded-full transition-all duration-300"
              style={{ width: `${((currentStep - 1) / 3) * 100}%` }}
            ></div>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>
              {currentStep === 1
                ? "Información Personal"
                : currentStep === 2
                  ? "Datos del Negocio"
                  : currentStep === 3
                    ? "Información de Productos"
                    : "Documentación"}
            </CardTitle>
            <CardDescription>
              {currentStep === 1
                ? "Ingresa tus datos personales para crear tu cuenta"
                : currentStep === 2
                  ? "Cuéntanos sobre tu negocio"
                  : currentStep === 3
                    ? "Información sobre los productos que venderás"
                    : "Sube los documentos requeridos para verificar tu negocio"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit}>
              {/* Step 1: Personal Information */}
              {currentStep === 1 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">
                        Nombre <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="firstName"
                        name="firstName"
                        value={personalInfo.firstName}
                        onChange={handlePersonalInfoChange}
                        placeholder="Tu nombre"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">
                        Apellidos <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="lastName"
                        name="lastName"
                        value={personalInfo.lastName}
                        onChange={handlePersonalInfoChange}
                        placeholder="Tus apellidos"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">
                        Correo electrónico <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={personalInfo.email}
                        onChange={handlePersonalInfoChange}
                        placeholder="tu@email.com"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">
                        Teléfono <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={personalInfo.phone}
                        onChange={handlePersonalInfoChange}
                        placeholder="+51 123 456 789"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="password">
                        Contraseña <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="password"
                        name="password"
                        type="password"
                        value={personalInfo.password}
                        onChange={handlePersonalInfoChange}
                        placeholder="Mínimo 8 caracteres"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">
                        Confirmar contraseña <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="confirmPassword"
                        name="confirmPassword"
                        type="password"
                        value={personalInfo.confirmPassword}
                        onChange={handlePersonalInfoChange}
                        placeholder="Confirma tu contraseña"
                        required
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Business Information */}
              {currentStep === 2 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="businessName">
                        Nombre del negocio <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="businessName"
                        name="businessName"
                        value={businessInfo.businessName}
                        onChange={handleBusinessInfoChange}
                        placeholder="Nombre de tu empresa o negocio"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="businessType">
                        Tipo de negocio <span className="text-red-500">*</span>
                      </Label>
                      <Select
                        value={businessInfo.businessType}
                        onValueChange={(value) => handleSelectChange("businessType", value)}
                      >
                        <SelectTrigger id="businessType">
                          <SelectValue placeholder="Selecciona el tipo de negocio" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="retail">Tienda minorista</SelectItem>
                          <SelectItem value="wholesale">Mayorista</SelectItem>
                          <SelectItem value="manufacturer">Fabricante</SelectItem>
                          <SelectItem value="service">Servicios</SelectItem>
                          <SelectItem value="artisan">Artesano</SelectItem>
                          <SelectItem value="other">Otro</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="ruc">
                        RUC <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="ruc"
                        name="ruc"
                        value={businessInfo.ruc}
                        onChange={handleBusinessInfoChange}
                        placeholder="Número de RUC (11 dígitos)"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="foundedYear">Año de fundación</Label>
                      <Select
                        value={businessInfo.foundedYear}
                        onValueChange={(value) => handleSelectChange("foundedYear", value)}
                      >
                        <SelectTrigger id="foundedYear">
                          <SelectValue placeholder="Selecciona el año" />
                        </SelectTrigger>
                        <SelectContent>
                          {Array.from({ length: 50 }, (_, i) => {
                            const year = new Date().getFullYear() - i
                            return (
                              <SelectItem key={year} value={year.toString()}>
                                {year}
                              </SelectItem>
                            )
                          })}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">
                      Descripción del negocio <span className="text-red-500">*</span>
                    </Label>
                    <Textarea
                      id="description"
                      name="description"
                      value={businessInfo.description}
                      onChange={handleBusinessInfoChange}
                      placeholder="Describe brevemente tu negocio y los productos o servicios que ofreces"
                      rows={4}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">
                      Dirección <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="address"
                      name="address"
                      value={businessInfo.address}
                      onChange={handleBusinessInfoChange}
                      placeholder="Dirección completa"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city">
                        Ciudad <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="city"
                        name="city"
                        value={businessInfo.city}
                        onChange={handleBusinessInfoChange}
                        placeholder="Ciudad"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="region">
                        Región <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="region"
                        name="region"
                        value={businessInfo.region}
                        onChange={handleBusinessInfoChange}
                        placeholder="Región/Departamento"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="postalCode">Código postal</Label>
                      <Input
                        id="postalCode"
                        name="postalCode"
                        value={businessInfo.postalCode}
                        onChange={handleBusinessInfoChange}
                        placeholder="Código postal"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="website">Sitio web</Label>
                    <Input
                      id="website"
                      name="website"
                      type="url"
                      value={businessInfo.website}
                      onChange={handleBusinessInfoChange}
                      placeholder="https://www.tunegocio.com (opcional)"
                    />
                  </div>
                </div>
              )}

              {/* Step 3: Product Information */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <div className="space-y-3">
                    <Label>
                      Categorías de productos <span className="text-red-500">*</span>
                    </Label>
                    <p className="text-sm text-gray-500">Selecciona las categorías que mejor describan tus productos</p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {[
                        "Ropa",
                        "Electrónica",
                        "Hogar",
                        "Joyería",
                        "Alimentos",
                        "Belleza",
                        "Salud",
                        "Juguetes",
                        "Deportes",
                        "Libros",
                        "Arte",
                        "Otros",
                      ].map((category) => (
                        <div key={category} className="flex items-center space-x-2">
                          <Checkbox
                            id={`category-${category}`}
                            checked={productInfo.categories.includes(category)}
                            onCheckedChange={() => handleCategoryToggle(category)}
                          />
                          <Label htmlFor={`category-${category}`} className="font-normal">
                            {category}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="averageProducts">
                      Número aproximado de productos <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={productInfo.averageProducts}
                      onValueChange={(value) => setProductInfo((prev) => ({ ...prev, averageProducts: value }))}
                    >
                      <SelectTrigger id="averageProducts">
                        <SelectValue placeholder="Selecciona un rango" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1-10">1-10 productos</SelectItem>
                        <SelectItem value="11-50">11-50 productos</SelectItem>
                        <SelectItem value="51-100">51-100 productos</SelectItem>
                        <SelectItem value="101-500">101-500 productos</SelectItem>
                        <SelectItem value="500+">Más de 500 productos</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-3">
                    <Label>Opciones de envío que ofrecerás</Label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {[
                        "Envío estándar",
                        "Envío express",
                        "Recojo en tienda",
                        "Envío internacional",
                        "Envío gratuito",
                      ].map((option) => (
                        <div key={option} className="flex items-center space-x-2">
                          <Checkbox
                            id={`shipping-${option}`}
                            checked={productInfo.shippingOptions.includes(option)}
                            onCheckedChange={() => handleShippingToggle(option)}
                          />
                          <Label htmlFor={`shipping-${option}`} className="font-normal">
                            {option}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="hasPhysicalStore"
                      checked={productInfo.hasPhysicalStore}
                      onCheckedChange={(checked) =>
                        setProductInfo((prev) => ({ ...prev, hasPhysicalStore: !!checked }))
                      }
                    />
                    <Label htmlFor="hasPhysicalStore" className="font-normal">
                      Tengo una tienda física además de mi tienda online
                    </Label>
                  </div>
                </div>
              )}

              {/* Step 4: Documents */}
              {currentStep === 4 && (
                <div className="space-y-6">
                  <div className="space-y-3">
                    <Label>Documentos requeridos</Label>
                    <p className="text-sm text-gray-500">
                      Por favor sube los siguientes documentos para verificar tu identidad y negocio
                    </p>

                    <div className="space-y-4">
                      <div className="border rounded-lg p-4 space-y-3">
                        <Label htmlFor="identityDocument">Documento de identidad (DNI o CE)</Label>
                        <div className="flex items-center space-x-3">
                          <Input
                            id="identityDocument"
                            type="file"
                            onChange={(e) => handleFileChange(e, "identityDocument")}
                            className="flex-1"
                          />
                          <div className="shrink-0">
                            <Upload className="h-5 w-5 text-gray-400" />
                          </div>
                        </div>
                        <p className="text-xs text-gray-500">Formatos aceptados: JPG, PNG, PDF. Máximo 5MB.</p>
                      </div>

                      <div className="border rounded-lg p-4 space-y-3">
                        <Label htmlFor="businessRegistration">Ficha RUC</Label>
                        <div className="flex items-center space-x-3">
                          <Input
                            id="businessRegistration"
                            type="file"
                            onChange={(e) => handleFileChange(e, "businessRegistration")}
                            className="flex-1"
                          />
                          <div className="shrink-0">
                            <Upload className="h-5 w-5 text-gray-400" />
                          </div>
                        </div>
                        <p className="text-xs text-gray-500">Formatos aceptados: JPG, PNG, PDF. Máximo 5MB.</p>
                      </div>

                      <div className="border rounded-lg p-4 space-y-3">
                        <Label htmlFor="taxDeclaration">Declaración de impuestos (opcional)</Label>
                        <div className="flex items-center space-x-3">
                          <Input
                            id="taxDeclaration"
                            type="file"
                            onChange={(e) => handleFileChange(e, "taxDeclaration")}
                            className="flex-1"
                          />
                          <div className="shrink-0">
                            <Upload className="h-5 w-5 text-gray-400" />
                          </div>
                        </div>
                        <p className="text-xs text-gray-500">Formatos aceptados: JPG, PNG, PDF. Máximo 5MB.</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 pt-4">
                    <div className="flex items-start space-x-3">
                      <Checkbox
                        id="acceptTerms"
                        checked={documents.acceptTerms}
                        onCheckedChange={(checked) => handleCheckboxChange("acceptTerms", !!checked)}
                        required
                      />
                      <div className="grid gap-1.5 leading-none">
                        <Label htmlFor="acceptTerms" className="font-normal">
                          Acepto los{" "}
                          <Link href="/terms" className="text-purple-700 hover:underline">
                            términos y condiciones
                          </Link>{" "}
                          para vendedores de QHATUY <span className="text-red-500">*</span>
                        </Label>
                        <p className="text-sm text-gray-500">
                          Al aceptar, confirmo que he leído y estoy de acuerdo con los términos para vendedores.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Checkbox
                        id="acceptPrivacyPolicy"
                        checked={documents.acceptPrivacyPolicy}
                        onCheckedChange={(checked) => handleCheckboxChange("acceptPrivacyPolicy", !!checked)}
                        required
                      />
                      <div className="grid gap-1.5 leading-none">
                        <Label htmlFor="acceptPrivacyPolicy" className="font-normal">
                          Acepto la{" "}
                          <Link href="/privacy" className="text-purple-700 hover:underline">
                            política de privacidad
                          </Link>{" "}
                          de QHATUY <span className="text-red-500">*</span>
                        </Label>
                        <p className="text-sm text-gray-500">
                          Entiendo cómo QHATUY utilizará mis datos personales y de negocio.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </form>
          </CardContent>
          <CardFooter className="flex flex-col sm:flex-row gap-3">
            {currentStep > 1 && (
              <Button type="button" variant="outline" onClick={handlePreviousStep}>
                Anterior
              </Button>
            )}
            {currentStep < 4 ? (
              <Button type="button" className={currentStep > 1 ? "sm:ml-auto" : ""} onClick={handleNextStep}>
                Siguiente
              </Button>
            ) : (
              <Button type="button" className="sm:ml-auto" onClick={handleSubmit} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Enviando...
                  </>
                ) : (
                  "Completar registro"
                )}
              </Button>
            )}
          </CardFooter>
        </Card>

        <div className="mt-8 text-center text-sm text-gray-500">
          ¿Ya tienes una cuenta?{" "}
          <Link href="/login" className="text-purple-700 hover:underline font-medium">
            Iniciar sesión
          </Link>
        </div>
      </div>
    </div>
  )
}
