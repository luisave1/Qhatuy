import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Navbar from "@/components/navbar"
import { CartProvider } from "@/context/cart-context"
import { AuthProvider } from "@/context/auth-context"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "QHATUY - Plataforma para Emprendedores",
  description: "Plataforma digital integral para emprendedores locales",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es">
      <body className={inter.className}>
        <AuthProvider>
          <CartProvider>
            <Navbar />
            <main className="min-h-screen pt-16">{children}</main>
            <footer className="bg-gray-800 text-white p-6">
              <div className="container mx-auto">
                <div className="flex flex-col md:flex-row justify-between">
                  <div className="mb-4 md:mb-0">
                    <h3 className="text-xl font-bold mb-2">QHATUY</h3>
                    <p>Impulsando emprendedores locales</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Contacto</h4>
                    <p>info@qhatuy.com</p>
                    <p>+51 123 456 789</p>
                  </div>
                </div>
                <div className="mt-6 text-center">
                  <p>© {new Date().getFullYear()} QHATUY. Todos los derechos reservados.</p>
                </div>
              </div>
            </footer>
            <Toaster />
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  )
}
