import { Button } from "@/components/ui/button"
import { ArrowRight, ShoppingBag, Users, BarChart3 } from "lucide-react"
import Link from "next/link"
import FeaturedProducts from "@/components/featured-products"

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-purple-700 to-indigo-900 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Impulsa tu negocio con QHATUY</h1>
              <p className="text-xl mb-6">
                La plataforma digital integral para emprendedores locales que quieren destacar en el mundo online.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/products">
                  <Button size="lg" className="bg-white text-purple-700 hover:bg-gray-100">
                    Ver Productos <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/register">
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                    Registrarse
                  </Button>
                </Link>
              </div>
            </div>
            <div className="md:w-1/2">
              <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg shadow-xl">
                <img src="/placeholder.svg?height=400&width=600" alt="QHATUY Platform" className="rounded-lg w-full" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">¿Por qué elegir QHATUY?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShoppingBag className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Ventas Online Simplificadas</h3>
              <p className="text-gray-600">
                Gestiona tu catálogo, procesa pedidos y aumenta tus ventas con nuestra plataforma intuitiva.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Fidelización de Clientes</h3>
              <p className="text-gray-600">
                Mantén una comunicación efectiva con tus clientes y construye relaciones duraderas.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <BarChart3 className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Análisis de Rendimiento</h3>
              <p className="text-gray-600">
                Accede a métricas clave para tomar decisiones informadas y hacer crecer tu negocio.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Productos Destacados</h2>
          <FeaturedProducts />
          <div className="text-center mt-10">
            <Link href="/products">
              <Button size="lg">
                Ver todos los productos <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
