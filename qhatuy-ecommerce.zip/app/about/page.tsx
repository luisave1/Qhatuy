import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-2">Sobre QHATUY</h1>
      <p className="text-gray-600 mb-10">
        Conoce nuestra historia y misión como plataforma para emprendedores locales.
      </p>

      <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
        <div>
          <h2 className="text-2xl font-semibold mb-4">Nuestra Historia</h2>
          <p className="text-gray-700 mb-4">
            QHATUY nació en 2023 con la visión de transformar la manera en que los emprendedores locales conectan con
            sus clientes. El nombre "QHATUY" proviene del quechua y significa "mercado" o "lugar de intercambio",
            representando perfectamente nuestra misión.
          </p>
          <p className="text-gray-700 mb-4">
            Fundada por un grupo de emprendedores que experimentaron de primera mano los desafíos de llevar un negocio
            local al mundo digital, QHATUY se ha convertido en una plataforma integral que no solo facilita las ventas
            online, sino que también construye comunidad.
          </p>
          <p className="text-gray-700">
            Hoy, QHATUY es el hogar digital de cientos de emprendedores peruanos que han encontrado en nuestra
            plataforma una manera efectiva de hacer crecer sus negocios y llegar a nuevos clientes.
          </p>
        </div>
        <div className="bg-gray-200 rounded-lg h-[400px] flex items-center justify-center">
          <p className="text-gray-600">Imagen de la historia de QHATUY</p>
        </div>
      </div>

      <div className="mb-16">
        <h2 className="text-2xl font-semibold mb-6 text-center">Nuestra Misión y Visión</h2>
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-medium mb-3 text-purple-700">Misión</h3>
            <p className="text-gray-700">
              Empoderar a los emprendedores locales proporcionándoles herramientas digitales accesibles y efectivas que
              les permitan competir en el mercado actual, conectar con sus clientes y hacer crecer sus negocios de
              manera sostenible.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-medium mb-3 text-purple-700">Visión</h3>
            <p className="text-gray-700">
              Ser la plataforma líder en Latinoamérica para emprendedores locales, reconocida por su impacto positivo en
              las economías locales y por crear un ecosistema digital donde los pequeños negocios puedan prosperar.
            </p>
          </div>
        </div>
      </div>

      <div className="mb-16">
        <h2 className="text-2xl font-semibold mb-6 text-center">Nuestros Valores</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8 text-purple-700"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h3 className="text-lg font-medium mb-2">Innovación</h3>
            <p className="text-gray-600">
              Buscamos constantemente nuevas formas de mejorar nuestra plataforma y ofrecer soluciones creativas a los
              desafíos de nuestros usuarios.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8 text-purple-700"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                />
              </svg>
            </div>
            <h3 className="text-lg font-medium mb-2">Comunidad</h3>
            <p className="text-gray-600">
              Creemos en el poder de la comunidad y en cómo juntos podemos lograr un mayor impacto en el desarrollo
              económico local.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8 text-purple-700"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                />
              </svg>
            </div>
            <h3 className="text-lg font-medium mb-2">Confianza</h3>
            <p className="text-gray-600">
              Construimos relaciones basadas en la transparencia, la honestidad y el compromiso con nuestros usuarios y
              sus clientes.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8 text-purple-700"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                />
              </svg>
            </div>
            <h3 className="text-lg font-medium mb-2">Adaptabilidad</h3>
            <p className="text-gray-600">
              Nos adaptamos constantemente a las necesidades cambiantes del mercado y de nuestros usuarios para ofrecer
              soluciones relevantes.
            </p>
          </div>
        </div>
      </div>

      <div className="mb-16">
        <h2 className="text-2xl font-semibold mb-6 text-center">Nuestro Equipo</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((member) => (
            <div key={member} className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="bg-gray-200 w-24 h-24 rounded-full mx-auto mb-4"></div>
              <h3 className="text-lg font-medium">Nombre Apellido</h3>
              <p className="text-purple-700 mb-2">Cargo</p>
              <p className="text-gray-600 text-sm">
                Breve descripción sobre la experiencia y rol de esta persona en QHATUY.
              </p>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-semibold mb-6 text-center">Únete a la Comunidad QHATUY</h2>
        <div className="bg-purple-700 text-white p-8 rounded-lg text-center">
          <h3 className="text-xl font-medium mb-4">¿Eres un emprendedor local?</h3>
          <p className="mb-6 max-w-2xl mx-auto">
            Únete a nuestra comunidad de emprendedores y lleva tu negocio al siguiente nivel con nuestras herramientas
            digitales.
          </p>
          <Link href="/register-seller">
            <button className="bg-white text-purple-700 px-6 py-2 rounded-md font-medium hover:bg-gray-100 transition-colors">
              Regístrate como vendedor
            </button>
          </Link>
        </div>
      </div>
    </div>
  )
}
