"use client"

import { useState } from "react"
import Link from "next/link"
import { useCart } from "@/context/cart-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Trash2, ArrowRight, ShoppingBag, ArrowLeft } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"

export default function CartPage() {
  const { cart, removeFromCart, updateQuantity, clearCart } = useCart()
  const { toast } = useToast()
  const router = useRouter()
  const [couponCode, setCouponCode] = useState("")
  const [couponApplied, setCouponApplied] = useState(false)
  const [couponDiscount, setCouponDiscount] = useState(0)

  // Calculate cart totals
  const subtotal = cart.reduce((total, item) => total + item.price * item.quantity, 0)
  const shipping = subtotal > 0 ? 10 : 0
  const discount = couponApplied ? subtotal * couponDiscount : 0
  const total = subtotal + shipping - discount

  const handleQuantityChange = (id: number, quantity: number) => {
    if (quantity < 1) return
    updateQuantity(id, quantity)
  }

  const handleRemoveItem = (id: number) => {
    removeFromCart(id)
    toast({
      title: "Producto eliminado",
      description: "El producto ha sido eliminado del carrito",
    })
  }

  const handleApplyCoupon = () => {
    if (couponCode.toLowerCase() === "qhatuy10") {
      setCouponApplied(true)
      setCouponDiscount(0.1) // 10% discount
      toast({
        title: "Cupón aplicado",
        description: "Se ha aplicado un descuento del 10% a tu compra",
      })
    } else {
      toast({
        title: "Cupón inválido",
        description: "El código de cupón ingresado no es válido",
        variant: "destructive",
      })
    }
  }

  const handleCheckout = () => {
    toast({
      title: "Procesando pedido",
      description: "Redirigiendo al proceso de pago...",
    })

    // Simulate checkout process
    setTimeout(() => {
      clearCart()
      router.push("/checkout/success")
    }, 1500)
  }

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-md mx-auto">
          <div className="bg-gray-100 p-6 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-6">
            <ShoppingBag className="h-12 w-12 text-gray-400" />
          </div>
          <h1 className="text-2xl font-bold mb-4">Tu carrito está vacío</h1>
          <p className="text-gray-600 mb-8">Parece que aún no has añadido ningún producto a tu carrito de compras.</p>
          <Link href="/products">
            <Button size="lg">
              <ArrowLeft className="mr-2 h-5 w-5" /> Continuar comprando
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl md:text-3xl font-bold mb-8">Carrito de Compras</h1>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="lg:w-2/3">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 border-b">
              <h2 className="font-semibold text-lg">Productos ({cart.length})</h2>
            </div>

            <div className="divide-y">
              {cart.map((item) => (
                <div key={item.id} className="p-4 flex flex-col sm:flex-row items-center gap-4">
                  <div className="w-20 h-20 flex-shrink-0">
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.title}
                      className="w-full h-full object-contain"
                    />
                  </div>

                  <div className="flex-grow">
                    <h3 className="font-medium">{item.title}</h3>
                    <p className="text-sm text-gray-500 capitalize">{item.category}</p>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="flex items-center">
                      <button
                        className="w-8 h-8 flex items-center justify-center border rounded-l-md"
                        onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                      >
                        -
                      </button>
                      <Input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) => handleQuantityChange(item.id, Number.parseInt(e.target.value) || 1)}
                        className="w-12 h-8 text-center border-y rounded-none"
                      />
                      <button
                        className="w-8 h-8 flex items-center justify-center border rounded-r-md"
                        onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                      >
                        +
                      </button>
                    </div>

                    <div className="text-right min-w-[80px]">
                      <div className="font-semibold">${(item.price * item.quantity).toFixed(2)}</div>
                      <div className="text-sm text-gray-500">${item.price.toFixed(2)} c/u</div>
                    </div>

                    <button className="text-red-500 hover:text-red-700" onClick={() => handleRemoveItem(item.id)}>
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6">
            <Link href="/products">
              <Button variant="outline">
                <ArrowLeft className="mr-2 h-4 w-4" /> Continuar comprando
              </Button>
            </Link>
          </div>
        </div>

        <div className="lg:w-1/3">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="font-semibold text-lg mb-4">Resumen del pedido</h2>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between">
                <span className="text-gray-600">Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Envío</span>
                <span>${shipping.toFixed(2)}</span>
              </div>
              {couponApplied && (
                <div className="flex justify-between text-green-600">
                  <span>Descuento (10%)</span>
                  <span>-${discount.toFixed(2)}</span>
                </div>
              )}
              <div className="border-t pt-3 mt-3 flex justify-between font-semibold text-lg">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>

            <div className="mb-6">
              <div className="flex gap-2">
                <Input
                  placeholder="Código de cupón"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                />
                <Button variant="outline" onClick={handleApplyCoupon}>
                  Aplicar
                </Button>
              </div>
              {couponApplied && (
                <p className="text-green-600 text-sm mt-2">Cupón QHATUY10 aplicado (10% de descuento)</p>
              )}
            </div>

            <Button className="w-full" size="lg" onClick={handleCheckout}>
              Proceder al pago <ArrowRight className="ml-2 h-5 w-5" />
            </Button>

            <div className="mt-4 text-sm text-gray-500">
              <p>Métodos de pago aceptados:</p>
              <div className="flex gap-2 mt-2">
                <div className="bg-gray-100 p-1 rounded">Visa</div>
                <div className="bg-gray-100 p-1 rounded">Mastercard</div>
                <div className="bg-gray-100 p-1 rounded">PayPal</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
