"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { CheckCircle, ShoppingBag } from "lucide-react"
import { useEffect, useState } from "react"

export default function CheckoutSuccessPage() {
  const [orderNumber, setOrderNumber] = useState("")

  useEffect(() => {
    // Generate a random order number
    const randomOrderNumber = Math.floor(100000 + Math.random() * 900000).toString()
    setOrderNumber(randomOrderNumber)
  }, [])

  return (
    <div className="container mx-auto px-4 py-16 text-center">
      <div className="max-w-md mx-auto">
        <div className="bg-green-100 p-6 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="h-12 w-12 text-green-600" />
        </div>
        <h1 className="text-2xl font-bold mb-4">¡Pedido completado con éxito!</h1>
        <p className="text-gray-600 mb-4">
          Gracias por tu compra. Tu pedido #{orderNumber} ha sido recibido y está siendo procesado.
        </p>
        <p className="text-gray-600 mb-8">
          Recibirás un correo electrónico con los detalles de tu pedido y la información de seguimiento.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/products">
            <Button size="lg">
              <ShoppingBag className="mr-2 h-5 w-5" /> Seguir comprando
            </Button>
          </Link>
          <Link href="/orders">
            <Button variant="outline" size="lg">
              Ver mis pedidos
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
